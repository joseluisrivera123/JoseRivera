package vallegrande.edu.pe.recuperacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecuperacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
